/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RM
 */
public class LoginManager {
    private static Login loginFrameInstance;

    // Private constructor to prevent instantiation
    private LoginManager() {}

    // Method to set the login frame instance
    public static void setLoginFrameInstance(Login instance) {
        loginFrameInstance = instance;
    }

    // Method to get the login frame instance
    public static Login getLoginFrameInstance() {
        return loginFrameInstance;
    }
}
