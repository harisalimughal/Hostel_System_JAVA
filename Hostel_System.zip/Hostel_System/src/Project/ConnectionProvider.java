package Project;

import java.sql.*;

public class ConnectionProvider {
    // Private static instance variable
    private static ConnectionProvider instance;
    
    // Private constructor to prevent instantiation
    private ConnectionProvider() {
        
    }
    
    // Public static method to get the instance
    public static ConnectionProvider getInstance() {
        if (instance == null) {
            instance = new ConnectionProvider();
        }
        return instance;
    }
    
    // Method to get a database connection
    public Connection getConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hostel", "root", "123456");
            return con;
        } catch (Exception e) {
            e.printStackTrace(); // Handle the exception appropriately
            return null;
        }
    }
}
